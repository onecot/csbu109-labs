const API_URL = 'http://localhost:5001/api/v1/products';

// 1. Load the product list from the backend
async function fetchProducts() {
    try {
        const response = await fetch(API_URL);
        const result = await response.json();

        const tbody = document.querySelector('#productTable tbody');
        tbody.innerHTML = '';

        result.data.forEach(p => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
        <td>${p.id}</td>
        <td>${p.name}</td>
        <td>${new Intl.NumberFormat('en-US').format(p.price)} VND</td>
        <td>${p.category}</td>
        <td><button class="btn-delete" onclick="deleteProduct(${p.id})">Delete</button></td>
      `;
            tbody.appendChild(tr);
        });
    } catch (error) {
        console.error('Error fetching products:', error);
    }
}

// 2. Add a new product
document.getElementById('productForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const productData = {
        name: document.getElementById('name').value,
        price: document.getElementById('price').value,
        category: document.getElementById('category').value
    };

    try {
        const response = await fetch(API_URL, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(productData)
        });

        if (response.ok) {
            document.getElementById('productForm').reset();
            fetchProducts(); // Reload the table
        }
    } catch (error) {
        console.error('Error adding product:', error);
    }
});

// 3. Delete a product
async function deleteProduct(id) {
    if (!confirm('Are you sure you want to delete this?')) return;
    try {
        await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
        fetchProducts();
    } catch (error) {
        console.error('Error deleting product:', error);
    }
}

fetchProducts();